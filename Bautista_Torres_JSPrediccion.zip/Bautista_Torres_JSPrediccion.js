//La primera funcion devuelve en la consola, al llamarla (Tengo: 25 años)//
//La segunda funcion a pesar de tener una variable en su interior, a diferencia de la otra, devuelve lo mismo que la anterior solo porque el numero asignado a la variable edad es 25 de lo contrario seguiria todo igual exepto el numero//
//En la tercera funcion la consola devuelve (¡Restemos los números! 
// primerNumero es: 50
// segundoNumero es: 27
// 23)//
//La primera funcion imprime (Tengo: 25 años)
//La segunda funcion imprime (Tengo: 25 años)
//La tercera funcion imprime (¡Restemos los números!
// primerNumero es: 50
// segundoNumero es: 27
// 23)